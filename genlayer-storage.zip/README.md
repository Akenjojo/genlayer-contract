# GenLayer Storage Contract

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Overview
This project is a simple but practical **smart contract built on GenLayer** that enables **persistent on-chain message storage**. The contract allows messages to be stored, updated, and retrieved transparently via blockchain transactions.

It is designed as a **foundation component** for decentralized applications (dApps), DAOs, and protocols requiring verifiable communication, configuration storage, or activity logging.

---

## Project Purpose
The goal of this project is to demonstrate:

- Core smart contract concepts on GenLayer  
- On-chain state persistence  
- Clear separation between read and write operations  
- Transparent and verifiable updates recorded on-chain  

While minimal by design, this contract reflects real-world usage patterns and can be extended into more advanced systems.

---

## Smart Contract Description

### Storage Contract
The contract maintains a single string value in on-chain storage.

**Key Functions:**

- `get_storage()` – Read the stored message (view-only)  
- `update_storage(new_storage)` – Update the stored message (state-changing)  

Each update is executed as a blockchain transaction, ensuring immutability and transparency.

---

## Usage Example

Here is a simple example showing how to interact with the storage contract:

```python
from genlayer import *

# Initialize contract (if deploying new)
storage_contract = UserStorage()

# Update the stored message
storage_contract.update_storage("Hello, GenLayer!")

# Retrieve the stored message
current_message = storage_contract.get_storage()
print("Stored message:", current_message)
```

This demonstrates **basic read and write operations**, which form the foundation for more complex dApps.

---

## Example Use Cases

- Protocol announcements  
- DAO updates and governance messages  
- Development activity logs  
- Configuration or metadata storage  
- On-chain notices for decentralized applications  

---

## My Contribution Summary
This repository reflects my **hands-on contribution** to building and understanding GenLayer smart contracts.

Over a **7-day period**, I:

- Initialized and deployed the storage contract  
- Implemented and tested read and write methods  
- Verified on-chain persistence of data  
- Reviewed security considerations around write access  
- Used the contract for real on-chain activity logging  
- Documented design decisions and future improvements  

This approach demonstrates consistent development activity and real-world usage beyond a simple demo.

---

## What I Learned

- How GenLayer manages persistent on-chain state  
- The importance of separating view and write functions  
- How blockchain immutability enables trust and transparency  
- Why simplicity and clarity are critical in smart contract design  
- How small contracts form the foundation of larger decentralized systems  

---

## Future Improvements

- Owner or role-based access control  
- Message versioning and history tracking  
- Timestamped updates  
- Integration with frontends and indexers  
- DAO or governance-based message updates  

---

## Tech Stack

- **GenLayer**  
- **Python Smart Contracts**  

---

## Repository

GitHub: [https://github.com/Akenjojo/genlayer-storage](https://github.com/Akenjojo/genlayer-storage)  

---

## License

MIT License — see [LICENSE](LICENSE)
