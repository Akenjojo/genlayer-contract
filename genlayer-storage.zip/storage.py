# storage.py
# v0.1.1
# { "Depends": "py-genlayer:latest" }

from genlayer import *

class UserStorage(gl.Contract):
    storage: TreeMap[Address, str]

    def __init__(self):
        # initialize the storage TreeMap
        self.storage = TreeMap()

    @gl.public.view
    def get_complete_storage(self) -> dict[str, str]:
        return {k.as_hex: v for k, v in self.storage.items()}

    @gl.public.view
    def get_account_storage(self, account_address: str) -> str:
        addr = Address(account_address)
        return self.storage.get(addr, "")

    @gl.public.write
    def update_storage(self, new_storage: str) -> None:
        self.storage[gl.message.sender_address] = new_storage
        gl.event("StorageUpdated", sender=gl.message.sender_address.as_hex, data=new_storage)
